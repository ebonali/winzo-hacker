import React from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { AIAssistantModal } from './components/AIAssistantModal';

// Pages
import { HomePage } from './pages/HomePage';
import { BuyBookPage } from './pages/BuyBookPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { LoginPage } from './pages/LoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { BookReaderPage } from './pages/BookReaderPage';
import { ContactPage } from './pages/ContactPage';
import { JoinPage } from './pages/JoinPage';

const ToastNotification: React.FC = () => {
  const { toastMessage } = useStore();
  if (!toastMessage) return null;

  return (
    <div className="fixed top-24 right-6 z-50 bg-slate-950 border border-amber-500/50 text-white px-5 py-3 rounded-2xl shadow-2xl backdrop-blur-2xl font-mono text-xs font-semibold flex items-center gap-3 animate-fade-in border-l-4 border-l-amber-500">
      <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
      <span>{toastMessage}</span>
    </div>
  );
};

const MainContent: React.FC = () => {
  const { currentRoute } = useStore();

  const renderRoute = () => {
    switch (currentRoute) {
      case 'home':
        return <HomePage />;
      case 'buy-book':
        return <BuyBookPage />;
      case 'checkout':
        return <CheckoutPage />;
      case 'login':
        return <LoginPage />;
      case 'admin':
        return <AdminDashboardPage />;
      case 'reader':
        return <BookReaderPage />;
      case 'contact':
        return <ContactPage />;
      case 'join':
        return <JoinPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      <Navbar />
      <ToastNotification />
      <main className="flex-1">
        {renderRoute()}
      </main>
      <Footer />
      <AIAssistantModal />
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <MainContent />
    </StoreProvider>
  );
}
