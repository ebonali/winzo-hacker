import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { BookOpen, Shield, LogOut, Menu, X, ChevronRight } from 'lucide-react';
import { PageRoute } from '../types';

export const Navbar: React.FC = () => {
  const { currentRoute, navigate, currentUser, signOut, hasAccess, authLoading } = useStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { label: string; route: PageRoute }[] = [
    { label: 'হোম', route: 'home' },
    { label: 'বই কিনুন', route: 'buy-book' },
    { label: 'সাপোর্ট', route: 'contact' },
    { label: 'কমিউনিটি', route: 'join' },
  ];

  const hasBookAccess = !!currentUser && hasAccess;
  const logout = () => signOut();

  const handleNav = (route: PageRoute) => {
    navigate(route);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-[#02040a]/90 border-b border-blue-500/20 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Logo */}
        <div 
          onClick={() => handleNav('home')} 
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 via-blue-600 to-indigo-600 shadow-[0_0_20px_rgba(56,189,248,0.4)] flex items-center justify-center text-white font-bold group-hover:scale-105 transition-transform">
            <BookOpen className="w-5 h-5 text-white stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-display font-extrabold text-lg text-white tracking-tight uppercase">
                কালার ট্রেডিং <span className="blue-text-gradient">মাস্টারি</span>
              </span>
            </div>
            <span className="text-[10px] uppercase tracking-wider text-sky-400/70 block -mt-0.5 font-mono">
              Color Trading Mastery Bangla
            </span>
          </div>
        </div>

        {/* Desktop Menu Navigation */}
        <nav className="hidden md:flex items-center gap-1.5 bg-white/[0.03] p-1.5 rounded-full border border-blue-500/20 backdrop-blur-md">
          {navItems.map((item) => {
            const isActive = currentRoute === item.route;
            return (
              <button
                key={item.route}
                onClick={() => handleNav(item.route)}
                className={`px-4 py-1.5 text-sm font-medium rounded-full transition-all cursor-pointer ${
                  isActive
                    ? 'text-sky-400 font-bold bg-blue-500/15 border border-sky-400/40 shadow-sm'
                    : 'text-white/70 hover:text-sky-300 hover:bg-white/5'
                }`}
              >
                {item.label}
              </button>
            );
          })}

          {/* Book Reader Access Button if authorized */}
          {hasBookAccess && (
            <button
              onClick={() => handleNav('reader')}
              className={`px-4 py-1.5 text-xs font-bold rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
                currentRoute === 'reader'
                  ? 'bg-emerald-500 text-slate-950'
                  : 'text-emerald-400 hover:bg-emerald-500/10 border border-emerald-500/30'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              ই-বুক রিডার
            </button>
          )}

          {/* Admin Dashboard shortcut if admin */}
          {currentUser?.role === 'admin' && (
            <button
              onClick={() => handleNav('admin')}
              className={`px-4 py-1.5 text-xs font-bold rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
                currentRoute === 'admin'
                  ? 'bg-blue-600 text-white'
                  : 'text-sky-400 hover:bg-blue-500/10 border border-sky-400/30'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              এডমিন ড্যাশবোর্ড
            </button>
          )}
        </nav>

        {/* Right CTAs & User Controls */}
        <div className="hidden lg:flex items-center gap-3">
          {authLoading ? (
            <span className="text-[11px] text-white/40 font-mono animate-pulse">লোড হচ্ছে...</span>
          ) : currentUser ? (
            <div className="flex items-center gap-2 bg-white/[0.03] border border-blue-500/20 p-1.5 pr-3 rounded-full">
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-sky-400 to-blue-600 text-white font-extrabold text-xs flex items-center justify-center">
                {currentUser.name.charAt(0).toUpperCase()}
              </div>
              <div className="text-left">
                <span className="text-xs font-semibold text-white block truncate max-w-[100px]">
                  {currentUser.name}
                </span>
              </div>
              <button
                onClick={logout}
                className="ml-1 p-1 text-white/40 hover:text-red-400 transition cursor-pointer"
                title="লগআউট"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => handleNav('login')}
              className="px-5 py-2 text-xs font-bold text-white/80 hover:text-white bg-white/5 hover:bg-white/10 border border-blue-500/30 rounded-full transition cursor-pointer"
            >
              লগইন
            </button>
          )}

          <button
            onClick={() => handleNav('buy-book')}
            className="px-6 py-2 bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 hover:from-sky-300 hover:to-blue-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-full shadow-lg shadow-blue-500/25 active:scale-95 transition-all cursor-pointer flex items-center gap-1.5 group"
          >
            <span>বই কিনুন ($49 USDT)</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {/* Mobile Hamburger Toggle */}
        <div className="flex items-center gap-2 md:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-white/80 hover:text-white bg-white/5 border border-blue-500/30 rounded-xl"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#02040a] border-b border-blue-500/20 px-4 py-6 space-y-3 animate-fade-in">
          {navItems.map((item) => (
            <button
              key={item.route}
              onClick={() => handleNav(item.route)}
              className={`w-full text-left px-4 py-3 rounded-2xl font-medium text-sm transition ${
                currentRoute === item.route
                  ? 'bg-blue-500/20 text-sky-400 border border-sky-400/40'
                  : 'text-white/70 hover:bg-white/5'
              }`}
            >
              {item.label}
            </button>
          ))}

          {hasBookAccess && (
            <button
              onClick={() => handleNav('reader')}
              className="w-full text-left px-4 py-3 rounded-2xl font-semibold text-sm bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center justify-between"
            >
              <span>অনলাইন ই-বুক পড়ুন</span>
              <BookOpen className="w-4 h-4" />
            </button>
          )}

          {currentUser?.role === 'admin' && (
            <button
              onClick={() => handleNav('admin')}
              className="w-full text-left px-4 py-3 rounded-2xl font-semibold text-sm bg-blue-500/10 text-sky-400 border border-sky-400/30 flex items-center justify-between"
            >
              <span>এডমিন ড্যাশবোর্ড</span>
              <Shield className="w-4 h-4" />
            </button>
          )}

          <div className="pt-4 border-t border-white/10 flex flex-col gap-2">
            {!currentUser ? (
              <button
                onClick={() => handleNav('login')}
                className="w-full py-3 text-center text-xs font-bold uppercase tracking-wider text-white bg-white/5 border border-white/10 rounded-xl"
              >
                লগইন / রেজিস্টার
              </button>
            ) : (
              <button
                onClick={logout}
                className="w-full py-3 text-center text-xs font-bold uppercase tracking-wider text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl"
              >
                লগআউট ({currentUser.email})
              </button>
            )}

            <button
              onClick={() => handleNav('buy-book')}
              className="w-full py-3 bg-gradient-to-r from-sky-400 to-blue-600 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-blue-500/20"
            >
              এখনই বই কিনুন ($49 USDT)
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
