import React from 'react';
import { BookOpen, ShieldCheck, Send, MessageCircle, Mail } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const Footer: React.FC = () => {
  const { navigate } = useStore();

  return (
    <footer className="bg-[#02040a] border-t border-blue-500/20 text-white/60 pt-16 pb-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          
          {/* Col 1: Brand */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-400 to-blue-600 p-0.5">
                <div className="w-full h-full bg-[#02040a] rounded-[10px] flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-sky-400" />
                </div>
              </div>
              <span className="font-display font-extrabold text-lg text-white tracking-tight">
                কালার ট্রেডিং মাস্টারি (বাংলা)
              </span>
            </div>
            <p className="text-sm text-white/60 leading-relaxed max-w-sm">
              ক্যান্ডেলস্টিক কালার বার প্রিসিশন, রিস্ক ম্যানেজমেন্ট এবং ট্রেডিং সাইকোলজির প্রাতিষ্ঠানিক পূর্ণাঙ্গ গাইডবুক।
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://t.me"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/80 hover:text-sky-400 hover:border-sky-500/50 transition"
              >
                <Send className="w-4 h-4" />
              </a>
              <a
                href="https://whatsapp.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/80 hover:text-emerald-400 hover:border-emerald-500/50 transition"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
              <a
                href="mailto:support@colortradingmastery.com"
                className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/80 hover:text-sky-400 hover:border-sky-500/50 transition"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Navigation */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white font-display uppercase tracking-wider">
              দ্রুত লিঙ্কসমূহ
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => navigate('home')} className="hover:text-sky-400 transition cursor-pointer">
                  হোমপেজ
                </button>
              </li>
              <li>
                <button onClick={() => navigate('buy-book')} className="hover:text-sky-400 transition cursor-pointer">
                  বই কিনুন ($49 USDT)
                </button>
              </li>
              <li>
                <button onClick={() => navigate('checkout')} className="hover:text-sky-400 transition cursor-pointer">
                  USDT (TRC20) চেকআউট
                </button>
              </li>
              <li>
                <button onClick={() => navigate('contact')} className="hover:text-sky-400 transition cursor-pointer">
                  সাপোর্ট ডেক্স
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Community & Access */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white font-display uppercase tracking-wider">
              পোর্টাল ও কমিউনিটি
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => navigate('join')} className="hover:text-sky-400 transition cursor-pointer">
                  টেলিগ্রাম ভিআইপি চ্যানেল
                </button>
              </li>
              <li>
                <button onClick={() => navigate('login')} className="hover:text-sky-400 transition cursor-pointer">
                  রিডার লগইন
                </button>
              </li>
              <li>
                <button onClick={() => navigate('reader')} className="hover:text-sky-400 transition cursor-pointer">
                  অনলাইন ই-বুক রিডার
                </button>
              </li>
              <li>
                <button onClick={() => navigate('admin')} className="hover:text-sky-400 transition cursor-pointer">
                  এডমিন প্যানেল
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Trust & Security */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white font-display uppercase tracking-wider">
              নিরাপত্তা গ্যারান্টি
            </h4>
            <div className="p-4 bento-card border-blue-500/30 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold">
                <ShieldCheck className="w-4 h-4" />
                <span>এনক্রিপ্টেড TRC20 পেমেন্ট</span>
              </div>
              <p className="text-xs text-white/60">
                TxID ট্র্যাকিং এর মাধ্যমে ১০০% সুরক্ষিত ডিজিটাল ই-বুক এক্সেস।
              </p>
            </div>
          </div>

        </div>

        {/* Bottom copyright & disclaimer */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-white/40">
          <p>© ২০২৬ কালার ট্রেডিং মাস্টারি। সর্বস্বত্ব সংরক্ষিত।</p>
          <p className="text-center md:text-right max-w-md">
            ফাইন্যান্সিয়াল মার্কেটে ট্রেডিং ঝুঁকিপূর্ণ। এই বইটির তথ্য শুধুমাত্র শিক্ষামূলক উদ্দেশ্যে সরবরাহ করা হয়েছে।
          </p>
        </div>
      </div>
    </footer>
  );
};
