import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { TRC20_WALLET_ADDRESS, BOOK_PRICE_USDT, BOOK_PRICE_BDT } from '../data/bookData';
import { Order } from '../types';
import { api } from '../lib/api';
import {
  Copy, Check, Upload, ShieldCheck, Clock,
  AlertCircle, Lock, Wallet, CreditCard, Loader2, CheckCircle2
} from 'lucide-react';

export const CheckoutPage: React.FC = () => {
  const { currentUser, navigate, showToast, refreshMe, myOrders } = useStore();

  const [paymentMethod, setPaymentMethod] = useState<'zinipay' | 'usdt'>('zinipay');
  const [txId, setTxId] = useState('');
  const [copiedAddress, setCopiedAddress] = useState(false);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [submittedOrder, setSubmittedOrder] = useState<Order | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCheckingZini, setIsCheckingZini] = useState(false);
  const [forceForm, setForceForm] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${TRC20_WALLET_ADDRESS}&color=38bdf8&bgcolor=020617`;

  // handle return from ZiniPay (?zini_order=<id> / ?zini_cancel=<id>)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ziniOrder = params.get('zini_order');
    const ziniCancel = params.get('zini_cancel');

    if (!ziniOrder && !ziniCancel) return;
    window.history.replaceState({}, '', window.location.pathname);

    if (ziniCancel) {
      showToast('পেমেন্ট বাতিল করা হয়েছে।');
      return;
    }

    setIsCheckingZini(true);
    api<{ status: 'approved' | 'pending' | 'rejected'; transactionId?: string | null }>(
      '/api/payment/zinipay/check',
      { method: 'POST', body: JSON.stringify({ orderId: ziniOrder }) }
    )
      .then(async (result) => {
        await refreshMe();
        if (result.status === 'approved') {
          setSubmittedOrder({
            id: ziniOrder,
            email: currentUser?.email || '',
            txId: result.transactionId || '-',
            screenshotUrl: null,
            amountUsdt: BOOK_PRICE_USDT,
            status: 'approved',
            createdAt: new Date().toISOString(),
          });
          showToast('পেমেন্ট সফল! ই-বুক রিডার আনলক হয়ে গেছে। 🎉');
        } else if (result.status === 'rejected') {
          showToast('পেমেন্ট ব্যর্থ হয়েছে। আবার চেষ্টা করুন।');
        } else {
          showToast('পেমেন্ট এখনো প্রসেসিং-এ আছে। কিছুক্ষণ পর আবার চেক করুন।');
        }
      })
      .catch((err) => showToast(err?.message || 'পেমেন্ট ভেরিফাই করা যায়নি।'))
      .finally(() => setIsCheckingZini(false));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (currentUser) refreshMe();
  }, [currentUser, refreshMe]);

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(TRC20_WALLET_ADDRESS);
    setCopiedAddress(true);
    showToast('TRC20 ওয়ালেট অ্যাড্রেস কপি হয়েছে!');
    setTimeout(() => setCopiedAddress(false), 3000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const startZinipayPayment = async () => {
    setError(null);
    setIsSubmitting(true);
    try {
      const data = await api<{ orderId: string; paymentUrl: string }>('/api/payment/zinipay/create', {
        method: 'POST',
        body: JSON.stringify({}),
      });
      // leave the app — go to ZiniPay hosted checkout page
      window.location.href = data.paymentUrl;
    } catch (err: any) {
      setError(err?.message || 'পেমেন্ট শুরু করা যায়নি।');
      setIsSubmitting(false);
    }
  };

  const handleSubmitUsdt = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!txId.trim() || txId.trim().length < 10) {
      setError('অনুগ্রহ করে আপনার USDT ট্রানজেকশন আইডি (TxID) সঠিকভাবে লিখুন।');
      return;
    }

    setIsSubmitting(true);
    try {
      const data = await api<{ order: Order }>('/api/orders', {
        method: 'POST',
        body: JSON.stringify({ txId: txId.trim(), screenshot: screenshotPreview }),
      });
      setSubmittedOrder(data.order);
      showToast('পেমেন্ট জমা দেওয়া হয়েছে! এডমিন ভেরিফিকেশনের অপেক্ষায় থাকুন।');
      refreshMe();
    } catch (err: any) {
      setError(err?.message || 'অর্ডার জমা দেওয়া যায়নি। আবার চেষ্টা করুন।');
    } finally {
      setIsSubmitting(false);
    }
  };

  // ---------- NOT LOGGED IN ----------
  if (!currentUser) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-blue-500/20 border border-sky-400/30 flex items-center justify-center text-sky-400 shadow-xl">
          <Lock className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white font-display">পেমেন্ট করতে আগে লগইন করুন</h2>
          <p className="text-white/70 text-sm">
            আপনার অর্ডার ও ই-বুক অ্যাক্সেস আপনার অ্যাকাউন্টের সাথে যুক্ত থাকবে। তাই নিরাপত্তার জন্য লগইন বাধ্যতামূলক।
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
          <button
            onClick={() => navigate('login')}
            className="px-6 py-3 bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white font-extrabold rounded-xl text-xs shadow-lg shadow-blue-500/20 cursor-pointer"
          >
            লগইন / সাইন আপ করুন
          </button>
          <button
            onClick={() => navigate('buy-book')}
            className="px-6 py-3 bg-white/5 border border-white/10 text-white rounded-xl text-xs font-semibold cursor-pointer"
          >
            বই সম্পর্কে জানুন
          </button>
        </div>
      </div>
    );
  }

  // ---------- ZiniPay verification spinner ----------
  if (isCheckingZini) {
    return (
      <div className="max-w-xl mx-auto px-4 py-24 text-center space-y-6">
        <Loader2 className="w-12 h-12 mx-auto animate-spin text-sky-400" />
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white font-display">পেমেন্ট যাঁচাই করা হচ্ছে...</h2>
          <p className="text-white/70 text-sm">
            আপনার পেমেন্টের স্ট্যাটাস ZiniPay-এর সাথে যাঁচাই করা হচ্ছে। একটু অপেক্ষা করুন।
          </p>
        </div>
      </div>
    );
  }

  const activeOrder = submittedOrder || myOrders[0] || null;

  // ---------- ORDER SUBMITTED / EXISTING ORDER STATUS ----------
  if (!forceForm && activeOrder && activeOrder.status !== 'rejected') {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 animate-fade-in space-y-8">

        <div className="bento-card p-8 sm:p-10 text-center space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-60 h-60 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />

          <div className="w-20 h-20 mx-auto rounded-3xl bg-blue-500/15 border border-sky-400/30 flex items-center justify-center text-sky-400 shadow-xl">
            {activeOrder.status === 'approved' ? (
              <ShieldCheck className="w-10 h-10 text-emerald-400" />
            ) : (
              <Clock className="w-10 h-10 animate-pulse" />
            )}
          </div>

          <div className="space-y-2">
            <span className={`px-3 py-1 border text-xs font-mono font-bold rounded-full ${
              activeOrder.status === 'approved'
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                : 'bg-white/5 text-sky-400 border-white/10'
            }`}>
              স্ট্যাটাস: {activeOrder.status === 'approved' ? 'অনুমোদিত' : 'ভেরিফিকেশন চলমান'}
            </span>
            <h2 className="text-3xl font-extrabold text-white font-display pt-2">
              {activeOrder.status === 'approved' ? 'পেমেন্ট অনুমোদিত হয়েছে!' : 'পেমেন্ট জমা দেওয়া হয়েছে'}
            </h2>
            <p className="text-white/70 text-sm max-w-lg mx-auto">
              {activeOrder.status === 'approved'
                ? 'অভিনন্দন! আপনার ই-বুক রিডার এখন আনলক হয়ে গেছে।'
                : 'আপনার USDT পেমেন্টটি বর্তমানে অ্যাডমিন ভেরিফিকেশনে রয়েছে। নিশ্চিত হওয়ার সাথে সাথেই আপনার অ্যাকাউন্টে ই-বুক রিডার আনলক করে দেওয়া হবে।'}
            </p>
          </div>

          <div className="bg-[#050505] p-5 rounded-2xl border border-white/10 text-left space-y-3 font-mono text-xs text-white/70">
            <div className="flex justify-between border-b border-white/10 pb-2">
              <span className="text-white/40">অর্ডার রেফারেন্স আইডি:</span>
              <span className="text-sky-400 font-bold truncate max-w-[220px]">{activeOrder.id}</span>
            </div>
            <div className="flex justify-between border-b border-white/10 pb-2">
              <span className="text-white/40">নিবন্ধিত জিমেইল:</span>
              <span className="text-white">{currentUser.email}</span>
            </div>
            <div className="flex justify-between border-b border-white/10 pb-2">
              <span className="text-white/40">পরিশোধিত পরিমাণ:</span>
              <span className="text-emerald-400 font-bold">${activeOrder.amountUsdt} USDT (TRC20)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/40">ট্রানজেকশন আইডি (TxID):</span>
              <span className="text-white/70 truncate max-w-[200px]" title={activeOrder.txId}>
                {activeOrder.txId}
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            {activeOrder.status === 'approved' ? (
              <button
                onClick={() => navigate('reader')}
                className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-emerald-400 to-emerald-600 text-white font-extrabold text-xs rounded-xl transition cursor-pointer"
              >
                ই-বুক রিডার খুলুন
              </button>
            ) : (
              <button
                onClick={() => { refreshMe(); showToast('অর্ডার স্ট্যাটাস রিফ্রেশ করা হয়েছে।'); }}
                className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white font-extrabold text-xs rounded-xl transition cursor-pointer"
              >
                স্ট্যাটাস রিফ্রেশ করুন
              </button>
            )}
            <button
              onClick={() => navigate('home')}
              className="w-full sm:w-auto px-6 py-3 bg-white/5 border border-white/10 text-white rounded-xl text-xs font-semibold hover:bg-white/10 transition cursor-pointer"
            >
              হোমপেজে ফিরে যান
            </button>
          </div>

          {activeOrder.status !== 'approved' && (
            <button
              onClick={() => setForceForm(true)}
              className="text-xs text-sky-400 hover:underline cursor-pointer"
            >
              অন্য পেমেন্ট মাধ্যম দিয়ে নতুন অর্ডার করুন →
            </button>
          )}

        </div>
      </div>
    );
  }

  // ---------- PAYMENT FORM ----------
  return (
    <div className="max-w-6xl mx-auto px-4 py-12 space-y-10">

      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-blue-500/10 border border-sky-400/30 text-sky-400 text-xs font-bold font-mono rounded-full">
          <ShieldCheck className="w-4 h-4" />
          <span>নিরাপদ চেকআউট • {BOOK_PRICE_BDT}৳ / ${BOOK_PRICE_USDT} USDT</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
          আপনার অর্ডার সম্পন্ন করুন
        </h1>
        <p className="text-white/70 text-sm">
          bKash/Nagad/Card (ZiniPay) বা TRC20 USDT — যেকোনো মাধ্যমে পেমেন্ট করুন।
        </p>
      </div>

      {/* Payment Method Tabs */}
      <div className="flex justify-center">
        <div className="flex bg-[#050505] p-1 rounded-xl border border-white/10 w-full max-w-md">
          <button
            type="button"
            onClick={() => setPaymentMethod('zinipay')}
            className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition cursor-pointer flex items-center justify-center gap-2 ${
              paymentMethod === 'zinipay'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <Wallet className="w-4 h-4" />
            ZiniPay (bKash/Nagad/Card)
          </button>
          <button
            type="button"
            onClick={() => setPaymentMethod('usdt')}
            className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition cursor-pointer flex items-center justify-center gap-2 ${
              paymentMethod === 'usdt'
                ? 'bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white shadow-md'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            USDT (TRC20)
          </button>
        </div>
      </div>

      {paymentMethod === 'zinipay' ? (
        /* ---------- ZINIPAY PANEL ---------- */
        <div className="max-w-2xl mx-auto">
          <div className="bento-card p-8 sm:p-10 space-y-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg">
                  <Wallet className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-display">ZiniPay সিকিউর চেকআউট</h3>
                  <span className="text-[11px] text-white/40 block font-mono">bKash • Nagad • Rocket • Card</span>
                </div>
              </div>
              <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs rounded-full border border-emerald-500/30">
                {BOOK_PRICE_BDT}৳
              </span>
            </div>

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-xs text-red-300">
                {error}
              </div>
            )}

            <ul className="space-y-2 text-xs text-white/70">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                পেমেন্ট সফল হলে ই-বুক রিডার <strong className="text-white">সাথে সাথেই অটোমেটিক আনলক</strong> হবে
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                এডমিন অনুমোদনের অপেক্ষা করতে হবে না
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                নিরাপদ হোস্টেড পেমেন্ট পেজে লেনদেন হবে
              </li>
            </ul>

            <button
              onClick={startZinipayPayment}
              disabled={isSubmitting}
              className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-xl shadow-emerald-500/30 active:scale-95 transition cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>ইনভয়েস তৈরি হচ্ছে...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5" />
                  <span>পেমেন্ট করুন ({BOOK_PRICE_BDT}৳)</span>
                </>
              )}
            </button>

            <p className="text-[11px] text-white/40 text-center">
              পেমেন্ট করতে ক্লিক করলে ZiniPay-এর নিরাপদ পেজে যাবেন। পেমেন্ট শেষে এখানেই ফিরে আসবেন।
            </p>
          </div>
        </div>
      ) : (
      /* ---------- USDT PANEL ---------- */
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

        {/* Left Column: Payment Details & Wallet QR */}
        <div className="lg:col-span-5 bento-card p-6 sm:p-8 space-y-6">

          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-sky-400/40 flex items-center justify-center font-extrabold font-mono text-sky-400 text-sm">
                ₮
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-display">
                  বাইন্যান্স USDT (TRC20)
                </h3>
                <span className="text-[11px] text-white/40 block font-mono">শুধুমাত্র Tron TRC20 নেটওয়ার্ক</span>
              </div>
            </div>
            <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs rounded-full border border-emerald-500/30">
              ${BOOK_PRICE_USDT} USDT
            </span>
          </div>

          <div className="bg-[#050505] p-6 rounded-2xl border border-white/10 flex flex-col items-center justify-center text-center space-y-3">
            <div className="p-3 bg-[#02040a] rounded-2xl border border-sky-400/30 shadow-xl">
              <img
                src={qrCodeUrl}
                alt="USDT TRC20 Wallet QR Code"
                className="w-40 h-40 rounded-lg"
              />
            </div>
            <span className="text-[11px] text-white/40 font-mono">
              বাইন্যান্স অ্যাপ বা ট্রনওয়ালেট দিয়ে স্ক্যান করুন
            </span>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-white/60 uppercase tracking-wider block font-mono">
              অফিশিয়াল ডিপোজিট TRC20 ওয়ালেট অ্যাড্রেস
            </label>
            <div className="bg-[#050505] border border-sky-400/30 p-3 rounded-2xl flex items-center justify-between gap-2">
              <span className="font-mono text-xs text-sky-300 font-semibold truncate select-all">
                {TRC20_WALLET_ADDRESS}
              </span>
              <button
                type="button"
                onClick={handleCopyAddress}
                className="px-3 py-1.5 bg-gradient-to-r from-sky-400 to-blue-600 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition shrink-0 cursor-pointer"
              >
                {copiedAddress ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedAddress ? 'কপি হয়েছে' : 'কপি করুন'}</span>
              </button>
            </div>
          </div>

          <div className="p-4 bg-[#050505] rounded-2xl border border-white/10 text-xs text-white/60 space-y-1">
            <p className="font-semibold text-sky-400 flex items-center gap-1">
              <AlertCircle className="w-4 h-4" /> জরুরি নির্দেশনা:
            </p>
            <p>বাইন্যান্স বা ট্রাস্ট ওয়ালেট থেকে পাঠানোর সময় নিশ্চিত করুন যে TRC20 (Tron Network) সিলেক্ট করেছেন। অন্য নেটওয়ার্কে পাঠালে পেমেন্ট বাতিল হতে পারে।</p>
          </div>

        </div>

        {/* Right Column: Submission Form */}
        <div className="lg:col-span-7 bento-card p-6 sm:p-8 space-y-6">
          <div>
            <h3 className="text-xl font-bold text-white font-display mb-1">
              পেমেন্ট ভেরিফিকেশন তথ্য জমা দিন
            </h3>
            <p className="text-white/50 text-xs">
              অ্যাডমিন যাচাই করে আপনার অ্যাকাউন্টে ই-বুক রিডার আনলক করে দেবেন।
            </p>
          </div>

          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-xs text-red-300">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmitUsdt} className="space-y-5">

            {/* Account email (read-only) */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-white/60 block font-mono">
                আপনার অ্যাকাউন্টের জিমেইল (ই-বুক এই অ্যাকাউন্টে আনলক হবে)
              </label>
              <input
                type="email"
                value={currentUser.email}
                readOnly
                className="w-full bg-[#050505] border border-white/10 rounded-xl px-4 py-3 text-sm text-white/60 outline-none font-sans cursor-not-allowed"
              />
            </div>

            {/* Transaction ID */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-white/60 block font-mono">
                বাইন্যান্স USDT ট্রানজেকশন আইডি (TxID / Hash) *
              </label>
              <input
                type="text"
                required
                value={txId}
                onChange={(e) => setTxId(e.target.value)}
                placeholder="যেমন: 8f912e73a02b1c4d5e6f7a8b9c0d1e2f3a4b5c6d"
                className="w-full bg-[#050505] border border-white/10 focus:border-sky-400 rounded-xl px-4 py-3 text-sm text-sky-300 font-mono outline-none"
              />
            </div>

            {/* Upload Payment Screenshot */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-white/60 block font-mono">
                পেমেন্ট স্ক্রিনশট আপলোড করুন (ঐচ্ছিক)
              </label>
              <div className="border-2 border-dashed border-white/10 hover:border-sky-400/50 rounded-2xl p-6 text-center bg-[#050505] transition cursor-pointer relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                />

                {screenshotPreview ? (
                  <div className="space-y-2">
                    <img
                      src={screenshotPreview}
                      alt="Payment Screenshot Preview"
                      className="max-h-36 mx-auto rounded-lg border border-sky-400/30 object-contain"
                    />
                    <span className="text-xs text-emerald-400 font-semibold block">
                      স্ক্রিনশট সফলভাবে যুক্ত করা হয়েছে
                    </span>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Upload className="w-8 h-8 text-sky-400 mx-auto" />
                    <span className="text-xs text-white/70 font-medium block">
                      পেমেন্ট রসিদের ছবি আপলোড করতে এখানে ক্লিক করুন
                    </span>
                    <span className="text-[10px] text-white/40 block">
                      JPG, PNG, WEBP ফরম্যাট (সর্বোচ্চ ১০ এমবি)
                    </span>
                  </div>
                )}
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-xl shadow-blue-500/30 active:scale-95 transition cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-5 h-5" />
              <span>{isSubmitting ? 'ট্রানজেকশন যাঁচাই করা হচ্ছে...' : `পেমেন্ট জমা দিন ($${BOOK_PRICE_USDT} USDT)`}</span>
            </button>

            <p className="text-[11px] text-white/40 text-center">
              পেমেন্ট জমা দেওয়ার মাধ্যমে আপনি আমাদের সেবার শর্তাবলীতে সম্মত হচ্ছেন।
            </p>

          </form>
        </div>

      </div>
      )}
    </div>
  );
};
