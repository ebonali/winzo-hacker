import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { BOOK_TITLE, BOOK_SUBTITLE, BOOK_PRICE_USDT, TESTIMONIALS_DATA, FAQS_DATA } from '../data/bookData';
import { ColorTradingSimulator } from '../components/ColorTradingSimulator';
import { 
  ShieldCheck, ArrowRight, Zap, TrendingUp, Brain, BookOpen, 
  CheckCircle2, ChevronDown, Star, Sparkles, Users, 
  Lock, RefreshCw, BarChart2, DollarSign
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const { navigate } = useStore();
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const BOOK_MOCKUP_IMG = "/src/assets/images/3d_book_mockup_1785989063995.jpg";
  const CHART_BG_IMG = "/src/assets/images/trading_chart_bg_1785989075612.jpg";

  const features = [
    {
      icon: TrendingUp,
      title: "প্রফেশনাল ট্রেডিং স্ট্র্যাটেজি",
      desc: "৩-রেড ক্যান্ডেল এক্সজশন, রেড-টু-গ্রিন এবজর্বশন ফ্লিপ এবং হাই-প্রোবাবিলিটি ট্রেন্ড কনটিন্যুয়েশন ট্রেড শিখুন।"
    },
    {
      icon: ShieldCheck,
      title: "ইনস্টিটিউশনাল রিস্ক ম্যানেজমেন্ট",
      desc: "অ্যাকাউন্টের সর্বোচ্চ ১-২% রিস্ক সীমা বজায় রেখে ১:৩+ প্রফিট টার্গেট অর্জনের সুনির্দিষ্ট গাণিতিক নিয়ম।"
    },
    {
      icon: Brain,
      title: "আবেগমুক্ত ট্রেডিং মানসিকতা",
      desc: "FOMO, রিভেঞ্জ ট্রেডিং এবং ভয় দূর করতে সুনির্দিষ্ট প্রি-ট্রেড চেকলিস্ট অনুসরণ করুন।"
    },
    {
      icon: BookOpen,
      title: "লাইফটাইম ডিজিটাল ই-বুক এক্সেস",
      desc: "আমাদের সুরক্ষিত অনলাইন ই-বুক রিডারে ওয়াটারমার্ক প্রটেকশনসহ আজীবন পড়ার সুযোগ পাবেন।"
    }
  ];

  const whyChooseCards = [
    {
      icon: Zap,
      title: "৯৮% কালার সিগন্যাল স্পষ্টতা",
      desc: "জটিল ইন্ডিকেটর ছাড়াই ক্যান্ডেলস্টিক রঙ ও ভলিউম দেখে ট্রেড এন্ট্রি চিনুন।"
    },
    {
      icon: Lock,
      title: "ক্যাপিটাল প্রটেকশন রুলস",
      desc: "পজিশন সাইজিং ক্যালকুলেটর ব্যবহার করে যেকোনো মার্কেট ক্র্যাশে নিজের ব্যালেন্স সুরক্ষিত রাখুন।"
    },
    {
      icon: RefreshCw,
      title: "ফ্রি লাইফটাইম আপডেট",
      desc: "ভবিষ্যতের নতুন অধ্যায়, নতুন চার্ট বিশ্লেষণ ও কেস স্টাডি ফ্রিতে পাবেন।"
    },
    {
      icon: BarChart2,
      title: "ভলিউম-ওয়েটেড ক্যান্ডেলস্টিক",
      desc: "খুচরা ট্রেডারদের ফাঁদ বনাম প্রাতিষ্ঠানিক বড় বিনিয়োগকারীদের আসল বাই/সেল ভলিউম চেনার কৌশল।"
    },
    {
      icon: DollarSign,
      title: "তাৎক্ষণিক USDT (TRC20) এক্সেস",
      desc: "সহজ ক্রিপ্টো পেমেন্ট পদ্ধতি ও দ্রুত ট্রানজেকশন ভেরিফিকেশন প্যানেল।"
    },
    {
      icon: Users,
      title: "এক্সক্লুসিভ ভিআইপি কমিউনিটি",
      desc: "১২,৪০০+ সক্রিয় ট্রেডারদের সাথে লাইভ চার্ট অ্যানালাইসিস শেয়ারিং।"
    }
  ];

  return (
    <div className="space-y-24 pb-20">
      
      {/* 1. HERO SECTION */}
      <section className="relative pt-12 pb-20 overflow-hidden">
        {/* Ambient chart background */}
        <div className="absolute inset-0 z-0 opacity-15 pointer-events-none">
          <img
            src={CHART_BG_IMG}
            alt="Trading Chart background"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#02040a] via-[#02040a]/90 to-[#02040a]" />
        </div>

        {/* Floating blue gradient blur lights */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-sky-500/15 rounded-full blur-[140px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Typography & CTAs */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-blue-500/10 rounded-full border border-sky-400/30 w-fit">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-semibold text-sky-300">নতুন প্রকাশিত: ২য় এডিশন (বাংলা ই-বুক)</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white font-display leading-[1.1] tracking-tight">
                ক্যান্ডেলস্টিক <span className="blue-text-gradient">কালার ট্রেডিং</span> শিখুন একজন পেশাদারের মতো।
              </h1>

              <p className="text-white/70 text-base sm:text-lg leading-relaxed max-w-2xl font-sans">
                {BOOK_SUBTITLE}। ল্যাগিং ইন্ডিকেটর ছাড়া খাঁটি প্রাইজ অ্যাকশন এবং ইনস্টিটিউশনাল রিস্ক ম্যানেজমেন্টের মাধ্যমে ট্রেডিংয়ে ধারাবাহিকতা আনুন।
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
                <button
                  onClick={() => navigate('buy-book')}
                  className="px-8 py-4 bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 hover:from-sky-300 hover:to-blue-500 text-white font-extrabold rounded-xl shadow-xl shadow-blue-500/30 active:scale-95 transition-transform uppercase text-xs tracking-widest cursor-pointer flex items-center justify-center gap-2 group"
                >
                  <span>এখনই বই কিনুন (${BOOK_PRICE_USDT} USDT)</span>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => {
                    const el = document.getElementById('about-book');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="px-8 py-4 bg-white/5 border border-sky-400/20 rounded-xl hover:bg-white/10 transition-colors uppercase text-xs tracking-widest font-semibold text-white cursor-pointer text-center"
                >
                  বিস্তারিত জানুন
                </button>
              </div>

              {/* Trust badges */}
              <div className="pt-6 border-t border-white/10 grid grid-cols-3 gap-4 text-left">
                <div>
                  <div className="text-xl font-extrabold text-white font-mono">১,৪২০+</div>
                  <div className="text-xs text-white/50">ভেরিফাইড পাঠক</div>
                </div>
                <div>
                  <div className="text-xl font-extrabold text-sky-400 font-mono">৪.৯৬ / ৫ ★</div>
                  <div className="text-xs text-white/50">ট্রেডার রেটিং</div>
                </div>
                <div>
                  <div className="text-xl font-extrabold text-emerald-400 font-mono">১০০% সুরক্ষিত</div>
                  <div className="text-xs text-white/50">বাইনান্স USDT</div>
                </div>
              </div>
            </div>

            {/* Right Column: 3D Book Visual */}
            <div className="lg:col-span-5 flex justify-center relative">
              <div className="relative group">
                <div className="absolute w-72 h-72 bg-blue-500/20 blur-[120px] rounded-full pointer-events-none" />
                
                <div className="relative rounded-2xl overflow-hidden border border-blue-500/30 shadow-[20px_40px_80px_rgba(0,0,0,0.8)] bg-[#050505] max-w-[320px] transform group-hover:scale-[1.02] transition duration-500">
                  <img
                    src={BOOK_MOCKUP_IMG}
                    alt="Color Trading Mastery 3D Book Mockup"
                    className="w-full h-auto object-cover"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Floating Price Pill */}
                  <div className="absolute top-4 right-4 bg-black/80 border border-sky-400/40 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-bold text-sky-300 font-mono shadow-lg">
                    ${BOOK_PRICE_USDT} USDT
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. BENTO GRID HIGHLIGHT SHOWCASE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="bento-card p-6 flex flex-col justify-between hover:border-sky-400/40 transition-all">
            <div className="w-10 h-10 rounded-full bg-sky-500/20 flex items-center justify-center text-sky-400 mb-4">
              <BarChart2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white mb-1">প্রফেশনাল স্ট্র্যাটেজি</h3>
              <p className="text-white/50 text-xs leading-relaxed">যেকোনো টাইমফ্রেমে কাজ করার উপযোগী গাণিতিক সেটআপ।</p>
            </div>
          </div>

          <div className="bento-card p-6 flex flex-col justify-between hover:border-blue-500/40 transition-all">
            <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 mb-4">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white mb-1">রিস্ক প্রটেকশন</h3>
              <p className="text-white/50 text-xs leading-relaxed">অ্যাকাউন্টের মূলধন সুরক্ষা ও লস নিয়ন্ত্রণের সুনির্দিষ্ট নিয়ম।</p>
            </div>
          </div>

          <div className="bento-card p-6 flex flex-col justify-between hover:border-indigo-500/40 transition-all">
            <div className="w-10 h-10 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400 mb-4">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white mb-1">সাইকোলজি নিয়ন্ত্রণ</h3>
              <p className="text-white/50 text-xs leading-relaxed">আবেগ দূর করে সুশৃঙ্খল ট্রেডিং পরিকল্পনা মেনে চলা।</p>
            </div>
          </div>

          <div className="bento-card-blue p-6 flex flex-col justify-between transition-all group">
            <div className="w-10 h-10 rounded-full bg-sky-400/20 flex items-center justify-center text-sky-300 mb-4">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white mb-1">বিশেষ সুবিধা</h3>
              <p className="text-sky-300/80 text-xs leading-relaxed">আজীবন ফ্রি আপডেট ও এক্সক্লুসিভ কমিউনিটি এক্সেস।</p>
            </div>
          </div>

        </div>
      </section>

      {/* 3. INTERACTIVE SIMULATOR SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ColorTradingSimulator />
      </section>

      {/* 4. FEATURES SECTION (4 Bento Cards) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-xs font-extrabold text-sky-400 uppercase tracking-widest mb-2 font-mono">
            কোর্সের মূল আকর্ষণসমূহ
          </h2>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
            সিরিয়াস ট্রেডারদের জন্য বিশেষভাবে তৈরি
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div
                key={idx}
                className="bento-card p-6 flex flex-col justify-between hover:border-sky-400/40 transition-all group"
              >
                <div>
                  <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-sky-400/20 flex items-center justify-center text-sky-400 mb-5 group-hover:scale-110 transition-transform">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-bold text-white font-display mb-2 group-hover:text-sky-300 transition">
                    {feat.title}
                  </h4>
                  <p className="text-white/50 text-xs leading-relaxed">
                    {feat.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 5. ABOUT BOOK SECTION */}
      <section id="about-book" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bento-card p-8 sm:p-12 relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left: Book Image */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-blue-500/20 blur-3xl rounded-full pointer-events-none" />
                <img
                  src={BOOK_MOCKUP_IMG}
                  alt="About the Book"
                  className="w-full max-w-[300px] h-auto rounded-2xl border border-white/10 shadow-2xl relative z-10"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            {/* Right: Detailed Bullet Points */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <div className="inline-block px-3 py-1 bg-white/5 border border-sky-400/20 text-sky-400 text-xs font-bold font-mono rounded-full">
                বইটির বিস্তারিত সারসংক্ষেপ
              </div>

              <h3 className="text-3xl font-extrabold text-white font-display">
                জটিল ল্যাগিং ইন্ডিকেটর বাদ দিয়ে খাঁটি প্রাইজ অ্যাকশন শিখুন
              </h3>

              <p className="text-white/70 text-sm sm:text-base leading-relaxed">
                পেশাদার ট্রেডারদের দ্বারা রচিত **কালার ট্রেডিং মাস্টারি** আপনাকে শেখাবে কীভাবে চার্টের শব্দ ও কোলাহল এড়িয়ে ক্যান্ডেলস্টিক রঙ ও ভলিউম বিশ্লেষণ করতে হয়। ক্রিপ্টো, ফরেক্স ও ফিউচার্স মার্কেটে এটি সমানভাবে কার্যকর।
              </p>

              <div className="space-y-3 pt-2">
                {[
                  "১৫টি পূর্ণাঙ্গ অধ্যায়ে বিভক্ত - Wingo পরিচিতি, ১-৯ সংখ্যার বিশ্লেষণ, প্রফেশনাল চার্ট ও মানি ম্যানেজমেন্ট",
                  "৩০ সেকেন্ডের মধ্যে সঠিক লট সাইজ হিসাব করার সহজ গাণিতিক সূত্র",
                  "১০,০০০+ ট্রেডে পরীক্ষিত উচ্চ-সফলতার ক্যান্ডেলস্টিক কালার সিগন্যাল",
                  "১০টি বাস্তব চার্ট কেস স্টাডি সহ এন্ট্রি, স্টপ লস ও টার্গেট পয়েন্ট",
                  "সুরক্ষিত অনলাইন ই-বুক রিডারে আজীবন এক্সেস সুবিধা"
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-3 text-white/80 text-sm">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4">
                <button
                  onClick={() => navigate('buy-book')}
                  className="px-6 py-3.5 bg-gradient-to-r from-sky-400 to-blue-600 text-white font-extrabold rounded-xl shadow-lg shadow-blue-500/25 transition cursor-pointer flex items-center gap-2"
                >
                  <span>এখনই এক্সেস পান (${BOOK_PRICE_USDT} USDT)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 6. WHY CHOOSE THIS BOOK */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-xs font-extrabold text-sky-400 uppercase tracking-widest font-mono mb-2">
            অনন্য সুবিধাসমূহ
          </h2>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
            কেন প্রফেশনাল ট্রেডাররা এই বইটি বেছে নেন
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {whyChooseCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={idx}
                className="bento-card p-6 space-y-3 hover:border-sky-400/30 transition duration-300"
              >
                <div className="w-10 h-10 rounded-full bg-blue-500/15 border border-sky-400/30 flex items-center justify-center text-sky-400">
                  <Icon className="w-5 h-5" />
                </div>
                <h4 className="text-lg font-bold text-white font-display">
                  {card.title}
                </h4>
                <p className="text-white/50 text-xs leading-relaxed">
                  {card.desc}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* 7. TESTIMONIALS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-xs font-extrabold text-sky-400 uppercase tracking-widest font-mono mb-2">
            পাঠকদের রিভিউ
          </h2>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
            সফল ট্রেডার পাঠকদের মতামত
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {TESTIMONIALS_DATA.map((t) => (
            <div
              key={t.id}
              className="bento-card p-6 flex flex-col justify-between space-y-4 hover:border-sky-400/30 transition"
            >
              <div className="space-y-3">
                <div className="flex items-center gap-1 text-sky-400">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-sky-400" />
                  ))}
                </div>
                <p className="text-white/80 text-xs italic leading-relaxed">
                  "{t.content}"
                </p>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={t.avatar}
                    alt={t.name}
                    className="w-10 h-10 rounded-full object-cover border border-sky-400/30"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h5 className="text-xs font-bold text-white font-display">
                      {t.name}
                    </h5>
                    <span className="text-[10px] text-white/40 block">
                      {t.role}
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                  {t.profitGain}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 8. FAQ ACCORDION SECTION */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-xs font-extrabold text-sky-400 uppercase tracking-widest font-mono mb-2">
            প্রশ্নোত্তর
          </h2>
          <h3 className="text-3xl font-extrabold text-white font-display">
            সাধারণত জিজ্ঞাসিত প্রশ্নাবলি (FAQ)
          </h3>
        </div>

        <div className="space-y-4">
          {FAQS_DATA.map((faq, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div
                key={idx}
                className="bento-card rounded-2xl overflow-hidden transition"
              >
                <button
                  onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-white/5 transition"
                >
                  <span className="font-bold text-white text-base font-display">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-sky-400 shrink-0 transition-transform ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-white/70 text-sm leading-relaxed border-t border-white/10 pt-4 animate-fade-in">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 9. FINAL CTA BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bento-card-blue p-8 sm:p-12 text-center relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />
          
          <div className="max-w-2xl mx-auto space-y-6 relative z-10">
            <h3 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
              আপনার ট্রেডিং দক্ষতা বাড়াতে প্রস্তুত?
            </h3>
            <p className="text-white/70 text-base">
              মাত্র **$49 USDT** দিয়ে কালার ট্রেডিং মাস্টারি ই-বুকের লাইফটাইম এক্সেস নিন। তাৎক্ষণিক পেমেন্ট ভেরিফিকেশন এবং অনলাইন রিডার আনলক।
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
              <button
                onClick={() => navigate('buy-book')}
                className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-sky-400 to-blue-600 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-xl shadow-blue-500/30 hover:scale-105 transition cursor-pointer flex items-center justify-center gap-2"
              >
                <span>বই কিনুন ($49 USDT)</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              <button
                onClick={() => navigate('contact')}
                className="w-full sm:w-auto px-8 py-4 bg-white/5 border border-white/10 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-white/10 transition cursor-pointer"
              >
                সাপোর্টে কথা বলুন
              </button>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
