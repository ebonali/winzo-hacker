import React, { useState } from 'react';
import { Send, MessageCircle, Mail, Facebook, CheckCircle2 } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const ContactPage: React.FC = () => {
  const { showToast } = useStore();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    showToast('আপনার মেসেজটি সরাসরি কালার ট্রেডিং সাপোর্ট টিম টিমের কাছে পাঠানো হয়েছে!');
  };

  const contactButtons = [
    {
      name: "অফিশিয়াল টেলিগ্রাম সাপোর্ট",
      handle: "@ColorTradingMastery",
      icon: Send,
      href: "https://t.me",
      color: "from-sky-400 to-blue-600",
      btnText: "টেলিগ্রামে মেসেজ দিন"
    },
    {
      name: "অফিশিয়াল হোয়াটসঅ্যাপ ডেস্ক",
      handle: "+১ (৮০০) ৫৫৫-কালার",
      icon: MessageCircle,
      href: "https://whatsapp.com",
      color: "from-emerald-400 to-green-600",
      btnText: "হোয়াটসঅ্যাপে মেসেজ দিন"
    },
    {
      name: "ফেসবুক ভিআইপি ট্রেডিং সার্কেল",
      handle: "facebook.com/groups/colortrading",
      icon: Facebook,
      href: "https://facebook.com",
      color: "from-blue-500 to-indigo-600",
      btnText: "ফেসবুক গ্রুপে যুক্ত হোন"
    },
    {
      name: "২৪/৭ ইমেইল সাপোর্ট ডেক্স",
      handle: "support@colortradingmastery.com",
      icon: Mail,
      href: "mailto:support@colortradingmastery.com",
      color: "from-sky-500 to-blue-700",
      btnText: "ইমেইল পাঠান"
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-16 space-y-12">
      
      {/* Heading */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="px-3.5 py-1 bg-blue-500/10 border border-sky-400/30 text-sky-400 text-xs font-bold font-mono rounded-full uppercase tracking-wider">
          ২৪/৭ ডাইরেক্ট সাপোর্ট ডেস্ক
        </span>
        <h1 className="text-4xl font-extrabold text-white font-display">
          আমাদের সাপোর্ট টিমের সাথে যোগাযোগ করুন
        </h1>
        <p className="text-white/70 text-sm">
          USDT পেমেন্ট ভেরিফিকেশন, রিডার এক্সেস কিংবা বইয়ের বিষয়বস্তু সম্পর্কিত যেকোনো তথ্যের জন্য নিচের মাধ্যমগুলোতে যোগাযোগ করুন।
        </p>
      </div>

      {/* 4 Large Contact Glassmorphism Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {contactButtons.map((btn, idx) => {
          const Icon = btn.icon;
          return (
            <div
              key={idx}
              className="bento-card p-6 flex flex-col justify-between space-y-4 hover:-translate-y-1 transition duration-300"
            >
              <div className="space-y-3">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${btn.color} p-0.5 shadow-lg`}>
                  <div className="w-full h-full bg-[#050505] rounded-[14px] flex items-center justify-center text-white">
                    <Icon className="w-6 h-6" />
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white font-display">
                    {btn.name}
                  </h3>
                  <p className="text-xs font-mono text-white/50">
                    {btn.handle}
                  </p>
                </div>
              </div>

              <a
                href={btn.href}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3 bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white font-extrabold text-xs rounded-xl transition text-center block cursor-pointer shadow-md"
              >
                {btn.btnText}
              </a>
            </div>
          );
        })}
      </div>

      {/* Quick Direct Message Form */}
      <div className="bento-card p-8 space-y-6">
        <div>
          <h3 className="text-xl font-bold text-white font-display">
            সরাসরি মেসেজ পাঠান
          </h3>
          <p className="text-xs text-white/50">
            আমাদের সাপোর্ট টিম সাধারণত ১৫ মিনিটের মধ্যে উত্তর দিয়ে থাকে।
          </p>
        </div>

        {submitted ? (
          <div className="p-6 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <h4 className="text-base font-bold text-white">মেসেজ পাওয়া গেছে!</h4>
            <p className="text-xs text-white/70">
              যোগাযোগ করার জন্য ধন্যবাদ। আমাদের প্রতিনিধি দ্রুতই **{email}** ঠিকানায় উত্তর দেবেন।
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-white/60 font-mono">আপনার নাম</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="আব্দুল্লাহ রহমান"
                  className="w-full bg-[#050505] border border-white/10 focus:border-sky-400 rounded-xl px-4 py-2.5 text-xs text-white outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-white/60 font-mono">আপনার জিমেইল</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="yourname@gmail.com"
                  className="w-full bg-[#050505] border border-white/10 focus:border-sky-400 rounded-xl px-4 py-2.5 text-xs text-white outline-none"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-white/60 font-mono">আপনার মেসেজ বা বার্তা</label>
              <textarea
                required
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="আপনাকে কীভাবে সাহায্য করতে পারি বিস্তারিত লিখুন..."
                className="w-full bg-[#050505] border border-white/10 focus:border-sky-400 rounded-xl px-4 py-2.5 text-xs text-white outline-none"
              />
            </div>

            <button
              type="submit"
              className="px-8 py-3 bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-blue-500/30 active:scale-95 transition cursor-pointer"
            >
              মেসেজ পাঠান
            </button>
          </form>
        )}
      </div>

    </div>
  );
};
