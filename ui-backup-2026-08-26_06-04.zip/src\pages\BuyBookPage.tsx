import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { BOOK_TITLE, BOOK_SUBTITLE, BOOK_PRICE_USDT, FAQS_DATA } from '../data/bookData';
import { 
  CheckCircle2, Star, ArrowRight, 
  Lock, ChevronDown, Check, X
} from 'lucide-react';

export const BuyBookPage: React.FC = () => {
  const { navigate } = useStore();
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const BOOK_MOCKUP_IMG = "/src/assets/images/3d_book_mockup_1785989063995.jpg";

  const includedPerks = [
    "অনলাইন সুরক্ষিত ই-বুক রিডারে আজীবন এক্সেস",
    "ভবিষ্যতের সকল অধ্যায় ও কেস স্টাডি আপডেট (১০০% ফ্রি)",
    "এক্সক্লুসিভ মেম্বারশিপ টেলিগ্রাম ও ডিসকর্ড চ্যানেল",
    "ইন্টারঅ্যাক্টিভ রিস্ক ম্যানেজমেন্ট ও পজিশন সাইজিং ক্যালকুলেটর",
    "ওয়াটারমার্ক নিরাপত্তা ও মাল্টি-ডিভাইস রেসপন্সিভ রিডার",
    "৩০ দিনের মানি-ব্যাক স্যাটিসফ্যাকশন গ্যারান্টি"
  ];

  const comparisonRows = [
    { feature: "প্রধান সিগন্যাল সোর্স", free: "ল্যাগিং MACD/RSI (বিলম্বিত)", book: "ক্যান্ডেলস্টিক কালার বার এবজর্বশন (লাইভ)" },
    { feature: "রিস্ক ম্যানেজমেন্ট", free: "আনুপাতিক সাইজিং ছাড়া অনুমানের ট্রেড", book: "অ্যাকাউন্টের সর্বোচ্চ ১.৫% রিস্ক সূত্র" },
    { feature: "টার্গেট পে-আউট", free: "নেগেটিভ বা ১:১ R:R", book: "নূন্যতম ১:৩+ রিস্ক-টু-রিওয়ার্ড টার্গেট" },
    { feature: "ট্রেডিং রুটিন", free: "১০ ঘণ্টার স্ক্রিন ফ্যাটিগ ও ক্লান্তি", book: "দৈনিক ৩০ মিনিটের সুনির্দিষ্ট স্ক্যান রুটিন" },
    { feature: "কমিউনিটি এক্সেস", free: "বিভ্রান্তিকর সোশ্যাল মিডিয়া হাইপ", book: "১২,৪০০+ ভেরিফাইড ভিআইপি ট্রেডার্স গ্রুপ" }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      
      {/* Top Breadcrumb & Heading */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="px-3.5 py-1 bg-blue-500/10 border border-sky-400/30 text-sky-400 text-xs font-bold font-mono rounded-full uppercase tracking-wider">
          সীমিত সময়ের বিশেষ অফার
        </span>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white font-display">
          তাৎক্ষণিক এক্সেস পান <span className="blue-text-gradient">{BOOK_TITLE}</span>
        </h1>
        <p className="text-white/70 text-base">
          হাজার হাজার পেশাদার ট্রেডারদের সাথে যোগ দিন যারা ক্যান্ডেলস্টিক কালার বার বিশ্লেষণ ব্যবহার করে ট্রেড করেন।
        </p>
      </div>

      {/* Main Product Showcase Card */}
      <div className="bento-card p-8 sm:p-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left: 3D Book Visual */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center space-y-4">
            <div className="relative group max-w-[320px]">
              <div className="absolute w-72 h-72 bg-blue-500/20 blur-[100px] rounded-full pointer-events-none" />
              <img
                src={BOOK_MOCKUP_IMG}
                alt="Book 3D Mockup"
                className="w-full h-auto rounded-2xl border border-white/10 shadow-[20px_40px_80px_rgba(0,0,0,0.8)] relative z-10"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="flex items-center gap-2 text-xs text-white/50 font-mono pt-2">
              <Lock className="w-3.5 h-3.5 text-sky-400" />
              <span>তাৎক্ষণিক ডিজিটাল এক্সেস | ওয়াটারমার্ক প্রটেক্টেড</span>
            </div>
          </div>

          {/* Right: Book Details & Pricing */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div>
              <div className="flex items-center gap-2 text-sky-400 mb-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-sky-400" />
                  ))}
                </div>
                <span className="text-sm font-bold font-mono text-white">৪.৯৬/৫.০</span>
                <span className="text-xs text-white/50">(১,৪২০+ পাঠকদের রিভিউ)</span>
              </div>

              <h2 className="text-3xl font-extrabold text-white font-display mb-2">
                {BOOK_TITLE}
              </h2>
              <p className="text-white/70 text-sm leading-relaxed">
                {BOOK_SUBTITLE}। ক্যান্ডেলস্টিক কালার বার এবজর্বশন, সঠিক পজিশন সাইজিং এবং মানসিক ভয় দূর করার কৌশল শিখুন।
              </p>
            </div>

            {/* Price Box */}
            <div className="p-6 bg-[#050505] rounded-2xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs uppercase tracking-wider text-white/50 block mb-1">লাইফটাইম এক্সেস মূল্য</span>
                <div className="flex items-baseline gap-3">
                  <span className="text-4xl font-extrabold text-sky-400 font-mono">${BOOK_PRICE_USDT} USDT</span>
                  <span className="text-sm text-white/30 line-through font-mono">$199 USDT</span>
                  <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded-full font-bold font-mono border border-emerald-500/30">
                    ৭৫% ছাড়
                  </span>
                </div>
                <span className="text-[11px] text-white/40 block mt-1">পেমেন্ট মাধ্যম: বাইন্যান্স USDT (TRC20)</span>
              </div>

              <button
                onClick={() => navigate('checkout')}
                className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 hover:from-sky-300 hover:to-blue-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-xl shadow-blue-500/30 active:scale-95 transition cursor-pointer flex items-center justify-center gap-2"
              >
                <span>এখনই কিনুন (${BOOK_PRICE_USDT} USDT)</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            {/* Included Checklist */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-sky-400 font-mono">
                অর্ডারের সাথে যা যা পাচ্ছেন:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {includedPerks.map((perk, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-white/80">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{perk}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>
      </div>

      {/* Feature Comparison Table */}
      <div className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h3 className="text-2xl font-bold text-white font-display">
            কেন কালার ট্রেডিং ঐতিহ্যবাহী ইন্ডিকেটরের চেয়ে বেশি কার্যকর?
          </h3>
          <p className="text-white/50 text-sm">
            সাধারন খুচরা ট্রেডারদের অভ্যাস বনাম বইটির প্রাতিষ্ঠানিক গাণিতিক নিয়মের তুলনা দেখুন।
          </p>
        </div>

        <div className="bento-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs sm:text-sm">
              <thead>
                <tr className="bg-[#050505] border-b border-white/10 text-white/40 font-mono uppercase text-[11px]">
                  <th className="p-4">ট্রেডিংয়ের দিক</th>
                  <th className="p-4 text-white/30">সাধারণ ইন্ডিকেটর ট্রেডিং</th>
                  <th className="p-4 text-sky-400 font-bold bg-blue-500/10">কালার ট্রেডিং মাস্টারি (বাংলা)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10 text-white/70">
                {comparisonRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-white/5 transition">
                    <td className="p-4 font-semibold text-white">{row.feature}</td>
                    <td className="p-4 text-white/40 flex items-center gap-2">
                      <X className="w-4 h-4 text-red-400 shrink-0" />
                      <span>{row.free}</span>
                    </td>
                    <td className="p-4 text-emerald-300 font-semibold bg-blue-500/10 flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{row.book}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* FAQ Accordion */}
      <div className="max-w-3xl mx-auto space-y-4">
        <h3 className="text-2xl font-bold text-white font-display text-center mb-6">
          চেকআউট ও এক্সেস সম্পর্কিত প্রশ্নাবলি
        </h3>

        {FAQS_DATA.map((faq, idx) => {
          const isOpen = openFaqIndex === idx;
          return (
            <div
              key={idx}
              className="bento-card overflow-hidden"
            >
              <button
                onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-white/5 transition"
              >
                <span className="font-bold text-white text-sm font-display">
                  {faq.question}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-sky-400 shrink-0 transition-transform ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {isOpen && (
                <div className="px-5 pb-5 text-white/70 text-xs sm:text-sm leading-relaxed border-t border-white/10 pt-4">
                  {faq.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>

    </div>
  );
};
