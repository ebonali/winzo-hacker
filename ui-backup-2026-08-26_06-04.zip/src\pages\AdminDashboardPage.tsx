import React, { useState, useEffect, useCallback } from 'react';
import { useStore } from '../context/StoreContext';
import { api } from '../lib/api';
import { Order } from '../types';
import {
  Shield, CheckCircle2, XCircle, Clock, Users, BookOpen,
  Search, Eye, Trash2, Plus, BarChart2, Lock, Loader2, RefreshCw
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  createdAt: string;
  hasAccess: boolean;
}

interface AdminStats {
  totalOrders: number;
  pendingOrders: number;
  approvedOrders: number;
  rejectedOrders: number;
  totalUsers: number;
  activeReaders: number;
  revenueUsdt: number;
  revenueByDay: Record<string, number>;
}

export const AdminDashboardPage: React.FC = () => {
  const { currentUser, navigate, showToast } = useStore();
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'users' | 'books'>('overview');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [newEmailInput, setNewEmailInput] = useState('');
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  const [orders, setOrders] = useState<Order[]>([]);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionBusy, setActionBusy] = useState<string | null>(null);

  const loadData = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [ordersRes, usersRes, statsRes] = await Promise.all([
        api<{ orders: Order[] }>('/api/admin/orders'),
        api<{ users: AdminUser[] }>('/api/admin/users'),
        api<AdminStats>('/api/admin/stats'),
      ]);
      setOrders(ordersRes.orders);
      setUsers(usersRes.users);
      setStats(statsRes);
    } catch (err: any) {
      showToast(err?.message || 'ডেটা লোড করা যায়নি।');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    if (currentUser?.role === 'admin') loadData();
  }, [currentUser, loadData]);

  // ---------- GUARD ----------
  if (!currentUser || currentUser.role !== 'admin') {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-red-500/15 border border-red-400/30 flex items-center justify-center text-red-400 shadow-xl">
          <Lock className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-white font-display">এডমিন অ্যাক্সেস প্রয়োজন</h2>
        <p className="text-white/70 text-sm">
          এই পেজটি শুধুমাত্র অনুমোদিত এডমিন অ্যাকাউন্টের জন্য। এডমিন অ্যাকাউন্ট দিয়ে লগইন করুন।
        </p>
        <button
          onClick={() => navigate('login')}
          className="px-6 py-3 bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white font-extrabold rounded-xl text-xs shadow-lg shadow-blue-500/20 cursor-pointer"
        >
          লগইন করুন
        </button>
      </div>
    );
  }

  const handleApprove = async (orderId: string) => {
    setActionBusy(orderId);
    try {
      await api(`/api/admin/orders/${orderId}/approve`, { method: 'POST' });
      showToast(`অর্ডার অনুমোদিত! পাঠকের এক্সেস চালু হয়েছে।`);
      await loadData(true);
    } catch (err: any) {
      showToast(err?.message || 'অনুমোদন করা যায়নি।');
    } finally {
      setActionBusy(null);
    }
  };

  const handleReject = async (orderId: string) => {
    setActionBusy(orderId);
    try {
      await api(`/api/admin/orders/${orderId}/reject`, { method: 'POST' });
      showToast('অর্ডার বাতিল করা হয়েছে।');
      await loadData(true);
    } catch (err: any) {
      showToast(err?.message || 'বাতিল করা যায়নি।');
    } finally {
      setActionBusy(null);
    }
  };

  const handleRevokeAccess = async (userId: string, email: string) => {
    setActionBusy(userId);
    try {
      await api('/api/admin/access/revoke', {
        method: 'POST',
        body: JSON.stringify({ userId }),
      });
      showToast(`${email} এর পারমিশন বাতিল করা হয়েছে।`);
      await loadData(true);
    } catch (err: any) {
      showToast(err?.message || 'পারমিশন বাতিল করা যায়নি।');
    } finally {
      setActionBusy(null);
    }
  };

  const handleAddEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmailInput.trim()) return;
    setActionBusy('grant');
    try {
      await api('/api/admin/access/grant', {
        method: 'POST',
        body: JSON.stringify({ email: newEmailInput.trim() }),
      });
      showToast(`অনুমোদিত পাঠক হিসেবে যোগ করা হয়েছে: ${newEmailInput.trim()}`);
      setNewEmailInput('');
      await loadData(true);
    } catch (err: any) {
      showToast(err?.message || 'পারমিশন দেওয়া যায়নি।');
    } finally {
      setActionBusy(null);
    }
  };

  // Filtered orders
  const filteredOrders = orders.filter((o) => {
    const matchesStatus = filterStatus === 'all' || o.status === filterStatus;
    const matchesSearch =
      (o.email || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (o.txId || '').toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const pendingOrders = stats?.pendingOrders ?? 0;
  const activeReaders = stats?.activeReaders ?? 0;

  // Chart data from real revenue by day
  const chartData = Object.entries(stats?.revenueByDay || {})
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-14)
    .map(([day, revenue]) => ({ day: day.slice(5), revenue }));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">

      {/* Top Header Banner */}
      <div className="bento-card p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-blue-500/20 border border-sky-400/40 flex items-center justify-center text-sky-400">
            <Shield className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                এডমিন কন্ট্রোল ড্যাশবোর্ড
              </h1>
              <span className="px-2.5 py-0.5 bg-white/5 text-sky-400 font-mono font-bold text-xs rounded-full border border-white/10">
                ভেরিফাইড এডমিন
              </span>
            </div>
            <p className="text-white/60 text-xs mt-1">
              TRC20 USDT পেমেন্ট যাঁচাই করুন, পাঠকদের পারমিশন দিন এবং মোট রেভিনিউ ট্র্যাক করুন।
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => loadData()}
            className="px-4 py-2.5 bg-white/5 border border-white/10 text-white rounded-xl text-xs font-semibold transition flex items-center gap-2 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>রিফ্রেশ</span>
          </button>
          <button
            onClick={() => navigate('reader')}
            className="px-4 py-2.5 bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white font-extrabold rounded-xl text-xs transition flex items-center gap-2 cursor-pointer shadow-md"
          >
            <BookOpen className="w-4 h-4" />
            <span>ই-বুক রিডার পরীক্ষা করুন</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Sidebar + Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

        {/* Sidebar Navigation */}
        <div className="lg:col-span-3 bento-card p-4 space-y-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`w-full px-4 py-3 rounded-xl font-bold text-xs flex items-center gap-3 transition cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/20'
                : 'text-white/70 hover:bg-white/5 hover:text-white'
            }`}
          >
            <BarChart2 className="w-4 h-4" />
            <span>ড্যাশবোর্ড ওভারভিউ</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`w-full px-4 py-3 rounded-xl font-bold text-xs flex items-center justify-between transition cursor-pointer ${
              activeTab === 'orders'
                ? 'bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/20'
                : 'text-white/70 hover:bg-white/5 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Clock className="w-4 h-4" />
              <span>USDT অর্ডারসমূহ</span>
            </div>
            {pendingOrders > 0 && (
              <span className="px-2 py-0.5 bg-sky-300 text-black text-[10px] font-mono font-bold rounded-full">
                {pendingOrders}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('users')}
            className={`w-full px-4 py-3 rounded-xl font-bold text-xs flex items-center gap-3 transition cursor-pointer ${
              activeTab === 'users'
                ? 'bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/20'
                : 'text-white/70 hover:bg-white/5 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>পাঠকগণ ({activeReaders})</span>
          </button>

          <button
            onClick={() => setActiveTab('books')}
            className={`w-full px-4 py-3 rounded-xl font-bold text-xs flex items-center gap-3 transition cursor-pointer ${
              activeTab === 'books'
                ? 'bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/20'
                : 'text-white/70 hover:bg-white/5 hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>বই ব্যবস্থাপনা</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="lg:col-span-9 space-y-6">

          {/* Top 4 Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-5 bento-card">
              <span className="text-[11px] text-white/40 uppercase font-mono block mb-1">মোট অর্ডার</span>
              <span className="text-2xl font-extrabold text-white font-mono">{stats?.totalOrders ?? '—'}</span>
            </div>

            <div className="p-5 bento-card border-sky-400/30">
              <span className="text-[11px] text-sky-400 uppercase font-mono block mb-1">পেন্ডিং রিভিউ</span>
              <span className="text-2xl font-extrabold text-sky-400 font-mono">{pendingOrders}</span>
            </div>

            <div className="p-5 bento-card border-emerald-500/30">
              <span className="text-[11px] text-emerald-400 uppercase font-mono block mb-1">অনুমোদিত আয়</span>
              <span className="text-2xl font-extrabold text-emerald-400 font-mono">${stats?.revenueUsdt ?? 0} USDT</span>
            </div>

            <div className="p-5 bento-card">
              <span className="text-[11px] text-white/40 uppercase font-mono block mb-1">সক্রিয় পাঠক</span>
              <span className="text-2xl font-extrabold text-white font-mono">{activeReaders}</span>
            </div>
          </div>

          {loading ? (
            <div className="bento-card p-16 flex items-center justify-center">
              <Loader2 className="w-8 h-8 animate-spin text-sky-400" />
            </div>
          ) : (
            <>
              {/* TAB 1: OVERVIEW & CHARTS */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div className="p-6 bento-card space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-base font-bold text-white font-display">
                        USDT রেভিনিউ ট্রেন্ড ($ USDT)
                      </h3>
                      <span className="text-xs font-mono text-emerald-400 font-bold">সর্বশেষ ১৪ দিন</span>
                    </div>

                    {chartData.length > 0 ? (
                      <div className="h-64 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={chartData}>
                            <defs>
                              <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.4}/>
                                <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                              </linearGradient>
                            </defs>
                            <XAxis dataKey="day" stroke="#64748b" fontSize={11} />
                            <YAxis stroke="#64748b" fontSize={11} />
                            <Tooltip contentStyle={{ backgroundColor: '#02040a', borderColor: '#38bdf8', borderRadius: '12px', color: '#fff' }} />
                            <Area type="monotone" dataKey="revenue" stroke="#38bdf8" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    ) : (
                      <div className="py-16 text-center text-white/40 text-xs font-mono">
                        এখনো কোনো অনুমোদিত আয় নেই।
                      </div>
                    )}
                  </div>

                  {/* Quick Pending Verification Banner */}
                  {pendingOrders > 0 && (
                    <div className="p-5 bento-card border-sky-400/40 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <Clock className="w-5 h-5 text-sky-400 shrink-0" />
                        <div>
                          <h4 className="text-sm font-bold text-white">
                            {pendingOrders}টি পেমেন্ট অর্ডার পর্যালোচনার অপেক্ষায়
                          </h4>
                          <p className="text-xs text-white/60">
                            পাঠক এক্সেস দিতে রসিদ ও ট্রানজেকশন আইডি যাঁচাই করুন।
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => setActiveTab('orders')}
                        className="px-4 py-2 bg-gradient-to-r from-sky-400 to-blue-600 text-white font-extrabold text-xs rounded-xl transition cursor-pointer"
                      >
                        রিভিউ করুন
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: ORDERS TABLE */}
              {(activeTab === 'orders' || activeTab === 'overview') && (
                <div className="bento-card p-6 space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
                    <h3 className="text-lg font-bold text-white font-display">
                      TRC20 পেমেন্ট অর্ডার তালিকা
                    </h3>

                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 text-white/40 absolute left-3 top-2.5" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder="জিমেইল বা TxID খুঁজুন..."
                          className="bg-[#050505] border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white outline-none focus:border-sky-400 w-48"
                        />
                      </div>

                      <select
                        value={filterStatus}
                        onChange={(e: any) => setFilterStatus(e.target.value)}
                        className="bg-[#050505] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-sky-400 font-mono outline-none"
                      >
                        <option value="all">সকল স্ট্যাটাস</option>
                        <option value="pending">পেন্ডিং</option>
                        <option value="approved">অনুমোদিত</option>
                        <option value="rejected">বাতিল</option>
                      </select>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-[#050505] text-white/40 font-mono uppercase text-[10px] border-b border-white/10">
                          <th className="p-3">ইউজার</th>
                          <th className="p-3">ট্রানজেকশন আইডি (TxID)</th>
                          <th className="p-3">রসিদের ছবি</th>
                          <th className="p-3">স্ট্যাটাস</th>
                          <th className="p-3 text-right">অ্যাকশন</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/10 text-white/70">
                        {filteredOrders.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="p-8 text-center text-white/40">
                              কোনো অর্ডার পাওয়া যায়নি।
                            </td>
                          </tr>
                        ) : (
                          filteredOrders.map((ord) => (
                            <tr key={ord.id} className="hover:bg-white/5 transition">
                              <td className="p-3">
                                <span className="font-semibold text-white block">{ord.userName || ord.email}</span>
                                <span className="text-white/40 text-[10px]">{ord.email}</span>
                              </td>
                              <td className="p-3 font-mono text-white/50 truncate max-w-[160px]" title={ord.txId}>
                                {ord.txId}
                              </td>
                              <td className="p-3">
                                {ord.screenshotUrl ? (
                                  <button
                                    onClick={() => setLightboxImage(ord.screenshotUrl)}
                                    className="px-2 py-1 bg-white/5 hover:bg-white/10 text-sky-400 rounded flex items-center gap-1 text-[10px] font-mono cursor-pointer border border-white/10"
                                  >
                                    <Eye className="w-3 h-3" />
                                    <span>ছবি দেখুন</span>
                                  </button>
                                ) : (
                                  <span className="text-white/30 italic text-[10px]">ছবি নেই</span>
                                )}
                              </td>
                              <td className="p-3">
                                {ord.status === 'approved' && (
                                  <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full font-bold font-mono text-[10px]">
                                    APPROVED
                                  </span>
                                )}
                                {ord.status === 'pending' && (
                                  <span className="px-2 py-0.5 bg-sky-500/20 text-sky-300 border border-sky-400/30 rounded-full font-bold font-mono text-[10px] animate-pulse">
                                    PENDING
                                  </span>
                                )}
                                {ord.status === 'rejected' && (
                                  <span className="px-2 py-0.5 bg-red-500/20 text-red-400 border border-red-500/30 rounded-full font-bold font-mono text-[10px]">
                                    REJECTED
                                  </span>
                                )}
                                <span className={`ml-1 px-2 py-0.5 rounded-full font-bold font-mono text-[9px] border ${
                                  ord.paymentMethod === 'zinipay'
                                    ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                                    : 'bg-blue-500/10 text-sky-300 border-sky-400/30'
                                }`}>
                                  {ord.paymentMethod === 'zinipay' ? 'ZINIPAY' : 'USDT'}
                                </span>
                              </td>
                              <td className="p-3 text-right space-x-2">
                                {ord.status !== 'approved' && (
                                  <button
                                    disabled={actionBusy === ord.id}
                                    onClick={() => handleApprove(ord.id)}
                                    className="px-3 py-1 bg-gradient-to-r from-sky-400 to-blue-600 text-white font-extrabold rounded text-[11px] transition cursor-pointer disabled:opacity-40"
                                  >
                                    এপ্রুভ করুন
                                  </button>
                                )}
                                {ord.status !== 'rejected' && (
                                  <button
                                    disabled={actionBusy === ord.id}
                                    onClick={() => handleReject(ord.id)}
                                    className="px-3 py-1 bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 rounded text-[11px] transition cursor-pointer disabled:opacity-40"
                                  >
                                    রিজেক্ট করুন
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 3: AUTHORIZED USERS */}
              {activeTab === 'users' && (
                <div className="bento-card p-6 space-y-6">
                  <div>
                    <h3 className="text-lg font-bold text-white font-display mb-1">
                      পাঠকবৃন্দের তালিকা
                    </h3>
                    <p className="text-xs text-white/50">
                      নিবন্ধিত সকল ইউজার ও তাদের ই-বুক পড়ার অনুমতির অবস্থা।
                    </p>
                  </div>

                  {/* Add Email Form */}
                  <form onSubmit={handleAddEmail} className="flex gap-2 max-w-md">
                    <input
                      type="email"
                      required
                      value={newEmailInput}
                      onChange={(e) => setNewEmailInput(e.target.value)}
                      placeholder="new.reader@gmail.com"
                      className="flex-1 bg-[#050505] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:border-sky-400 outline-none"
                    />
                    <button
                      type="submit"
                      disabled={actionBusy === 'grant'}
                      className="px-4 py-2 bg-gradient-to-r from-sky-400 to-blue-600 text-white font-extrabold text-xs rounded-xl transition flex items-center gap-1 cursor-pointer disabled:opacity-40"
                    >
                      <Plus className="w-4 h-4" />
                      <span>পারমিশন দিন</span>
                    </button>
                  </form>

                  {/* List */}
                  <div className="divide-y divide-white/10 border-t border-white/10 pt-2">
                    {users.map((u) => (
                      <div key={u.id} className="py-3 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          {u.hasAccess ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <XCircle className="w-4 h-4 text-white/30" />
                          )}
                          <div>
                            <span className="font-mono text-white font-semibold block">{u.email}</span>
                            <span className="text-white/40 text-[10px]">
                              {u.name} {u.role === 'admin' ? '• এডমিন' : ''}
                            </span>
                          </div>
                        </div>
                        {u.role !== 'admin' && (
                          u.hasAccess ? (
                            <button
                              disabled={actionBusy === u.id}
                              onClick={() => handleRevokeAccess(u.id, u.email)}
                              className="p-1 text-white/40 hover:text-red-400 transition cursor-pointer disabled:opacity-40"
                              title="পারমিশন বাতিল করুন"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          ) : (
                            <span className="text-white/30 italic text-[10px]">এক্সেস নেই</span>
                          )
                        )}
                      </div>
                    ))}
                    {users.length === 0 && (
                      <div className="py-8 text-center text-white/40 text-xs font-mono">
                        কোনো ইউজার নেই।
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: BOOKS MANAGEMENT */}
              {activeTab === 'books' && (
                <div className="bento-card p-6 space-y-4">
                  <h3 className="text-lg font-bold text-white font-display">
                    ডিজিটাল ই-বুক রেকর্ড
                  </h3>
                  <div className="p-4 bg-[#050505] rounded-xl border border-sky-400/30 flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-white font-display">
                        WINGO HACKER (জিরো থেকে এডভান্স)
                      </h4>
                      <p className="text-xs text-white/50">
                        ১৫টি অধ্যায় | সুরক্ষিত অনলাইন রিডার | ওয়াটারমার্ক সহ
                      </p>
                    </div>
                    <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 font-mono text-xs font-bold rounded-full border border-emerald-500/30">
                      সক্রিয় বই
                    </span>
                  </div>
                  <p className="text-xs text-white/40">
                    বইয়ের কনটেন্ট সার্ভারে সংরক্ষিত — শুধুমাত্র অনুমোদিত পাঠকদের কাছে chapter-by-chapter পাঠানো হয়।
                  </p>
                </div>
              )}
            </>
          )}

        </div>

      </div>

      {/* Lightbox Modal for Receipt Screenshots */}
      {lightboxImage && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bento-card p-6 max-w-xl w-full relative space-y-4">
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute top-4 right-4 p-2 text-white/60 hover:text-white bg-white/5 rounded-full cursor-pointer"
            >
              <XCircle className="w-6 h-6" />
            </button>
            <h4 className="text-sm font-bold text-white font-display">
              পেমেন্ট স্ক্রিনশট প্রিভিউ
            </h4>
            <img
              src={lightboxImage}
              alt="Receipt Preview"
              className="w-full h-auto max-h-[70vh] object-contain rounded-xl border border-white/10"
            />
          </div>
        </div>
      )}

    </div>
  );
};
